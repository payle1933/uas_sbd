# klinik_fitri

Nama			| : Fitriyanah
--------- | ----------
NIM				| : 312010121
Kelas			| : TI.20.D2



## 1. Dashboard
![dashboard](https://user-images.githubusercontent.com/106644837/179365199-5f779ada-51a2-4003-aa79-01b64ac19d56.png)

## 2. Login
![login new](https://user-images.githubusercontent.com/106644837/179365237-1a4dbd3d-4021-44df-b851-8ca0b92cbb00.png)

## 3. Data Dokter
![dokter](https://user-images.githubusercontent.com/106644837/179365251-774d8803-a5c7-4c35-9ad7-b73a1a3a057d.png)

## 4. Data Pasien
![pasien](https://user-images.githubusercontent.com/106644837/179365293-6230873b-c7ef-4b5a-b985-c4030ffa29f4.png)

### - Edit data pasien
![edit data pasien](https://user-images.githubusercontent.com/106644837/179365351-2096b6df-bc88-4bcd-a0e4-f0f2e3d8743b.png)

### - Tambah data pasien
![tambah data pasien](https://user-images.githubusercontent.com/106644837/179365374-0ae02e39-d321-4237-ab3f-9d15eb1c0de4.png)

## 5. Data Obat
![obat](https://user-images.githubusercontent.com/106644837/179365407-09e809a6-ed16-445a-b876-50cf00ad3834.png)

## 6. Rekap Medis
![rekam medis](https://user-images.githubusercontent.com/106644837/179365470-42e67cd4-5c70-4358-88e9-d3d8ed07d341.png)

### - Tampilan data rekap medis
![tampilan data rekam medis](https://user-images.githubusercontent.com/106644837/179365516-94160d49-71db-4411-9e2d-ffbe0b9facf3.png)
