<section class="konten mt-2">
    <div class="container-fluid">
        <div class="card border-primary">
            <div class="card-header" style="background-color: #e3f2fd;">
                <?= $title; ?>

                <a href="<?= base_url('pasien'); ?>" class="btn btn-warning btn-sm float-end">Kembali</a>
            </div>
            <div class="card-body">
                <form method="post" action="<?= base_url('pasien/update'); ?>">
                    <input type="hidden" name="id" value="<?= $r['id_pasien']; ?>">
                    <div class="form-group">
                        <label for="">Nama Pasien</label>
                        <input type="text" name="nama_pasien" value="<?= $r['nama_pasien'] ?>" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label for="">Jenis Kelamin</label>
                        <select name="jenis_kelamin" id="" class="form-control" required>
                            <option value="<?= $r['jenis_kelamin'] ?>"><?= $r['jenis_kelamin']; ?></option>
                            <option value="Perempuan">Perempuan</option>
                            <option value="Laki-laki">Laki-laki</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="">Umur</label>
                        <input type="number" name="umur" value="<?= $r['umur'] ?>" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <button type="submit" class="btn btn-primary btn-sm">
                            Update
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>